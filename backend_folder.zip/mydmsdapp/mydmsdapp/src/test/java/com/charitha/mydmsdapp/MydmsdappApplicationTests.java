package com.charitha.mydmsdapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MydmsdappApplicationTests {

	@Test
	void contextLoads() {
	}

}
