package com.charitha.mydmsdapp.entity;

public enum Status {
    REGULAR, SILVER, GOLD, PLATINUM
}
