package com.charitha.mydmsdapp.controller;

import com.charitha.mydmsdapp.dto.*;
import com.charitha.mydmsdapp.entity.Basket;
import com.charitha.mydmsdapp.entity.CreditCard;
import com.charitha.mydmsdapp.entity.Customer;
import com.charitha.mydmsdapp.entity.ShippingAddress;
import com.charitha.mydmsdapp.entity.AppearsIn;
import com.charitha.mydmsdapp.service.MainService;
import com.charitha.mydmsdapp.entity.Transaction;
import com.charitha.mydmsdapp.entity.OfferProduct;
import com.charitha.mydmsdapp.entity.Computer;
import com.charitha.mydmsdapp.entity.Laptop;
import com.charitha.mydmsdapp.entity.Printer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class MainController {

    @Autowired
    private MainService mainService;


    @PostMapping("/customer")
    public Customer registerCustomer(@RequestBody Customer customer) {
        return mainService.registerCustomer(customer);
    }

    @GetMapping("/customer/{id}")
    public Optional<Customer> getCustomer(@PathVariable int id) {
        return mainService.getCustomerById(id);
    }

    @PutMapping("/customer/{id}")
    public Customer updateCustomer(@PathVariable int id, @RequestBody Customer customer) {
        return mainService.updateCustomer(id, customer);
    }

    @DeleteMapping("/customer/{id}")
    public String deleteCustomer(@PathVariable int id) {
        mainService.deleteCustomer(id);
        return "Customer deleted successfully";
    }



    @PostMapping("/customer/{customerId}/creditcard")
    public CreditCard addOrUpdateCreditCard(@PathVariable Integer customerId, @RequestBody CreditCard creditCard) {
        return mainService.saveCreditCard(creditCard, customerId);
    }

    @GetMapping("/customer/{customerId}/creditcards")
    public List<CreditCard> getCreditCards(@PathVariable Integer customerId) {
        return mainService.getCreditCardsByCustomer(customerId);
    }

    @DeleteMapping("/creditcard/{ccNumber}")
    public String deleteCreditCard(@PathVariable String ccNumber) {
        mainService.deleteCreditCard(ccNumber);
        return "Credit card deleted successfully";
    }

    // SHIPPING ADDRESS APIs

    @PostMapping("/customer/{customerId}/shippingaddress")
    public ShippingAddress addOrUpdateShippingAddress(
            @PathVariable Integer customerId,
            @RequestBody ShippingAddress address) {
        return mainService.saveShippingAddress(address, customerId);
    }

    @GetMapping("/customer/{customerId}/shippingaddresses")
    public List<ShippingAddress> getShippingAddresses(@PathVariable Integer customerId) {
        return mainService.getShippingAddressesByCustomer(customerId);
    }

    @DeleteMapping("/customer/{customerId}/shippingaddress/{saName}")
    public String deleteShippingAddress(@PathVariable Integer customerId, @PathVariable String saName) {
        mainService.deleteShippingAddress(customerId, saName);
        return "Shipping address deleted successfully";
    }

    //  BASKET APIs

    @PostMapping("/customer/{customerId}/basket")
    public Basket createBasket(@PathVariable Integer customerId) {
        return mainService.createBasketForCustomer(customerId);
    }

    @GetMapping("/customer/{customerId}/baskets")
    public List<Basket> getBasketsByCustomer(@PathVariable Integer customerId) {
        return mainService.getBasketsByCustomer(customerId);
    }

    @DeleteMapping("/basket/{basketId}")
    public String deleteBasket(@PathVariable Integer basketId) {
        mainService.deleteBasket(basketId);
        return "Basket deleted successfully";
    }
    @PostMapping("/basket/{basketId}/addproduct")
    public AppearsIn addProductToBasket(@PathVariable Integer basketId, @RequestBody AppearsIn appearsIn) {
        return mainService.addProductToBasket(basketId, appearsIn);
    }



    @GetMapping("/basket/{basketId}/products")
    public List<AppearsIn> getProductsInBasket(@PathVariable Integer basketId) {
        return mainService.getProductsInBasket(basketId);
    }

    @DeleteMapping("/basket/{basketId}/product/{productId}")
    public String removeProductFromBasket(@PathVariable Integer basketId, @PathVariable Integer productId) {
        mainService.removeProductFromBasket(basketId, productId);
        return "Product removed from basket";
    }
    //  TRANSACTION APIs

    @PostMapping("/basket/{basketId}/transaction")
    public Transaction placeOrder(
            @PathVariable Integer basketId,
            @RequestBody Transaction transaction
    ) {
        // Set basket reference before saving
        Basket basket = new Basket();
        basket.setBid(basketId);
        transaction.setBasket(basket);

        return mainService.saveTransaction(transaction);
    }






    @GetMapping("/basket/{basketId}/transactions")
    public List<Transaction> getTransactionsByBasket(@PathVariable Integer basketId) {
        return mainService.getTransactionsByBasket(basketId);
    }






    //  OFFER PRODUCT APIs

    @PostMapping("/offerproduct")
    public OfferProduct createOrUpdateOffer(@RequestBody OfferProduct offerProduct) {
        return mainService.saveOfferProduct(offerProduct);
    }

    @GetMapping("/offerproducts")
    public List<OfferProduct> getAllOfferProducts() {
        return mainService.getAllOfferProducts();
    }

    @DeleteMapping("/offerproduct/{productId}")
    public String deleteOfferProduct(@PathVariable Integer productId) {
        mainService.deleteOfferProduct(productId);
        return "OfferProduct deleted successfully";
    }
    @GetMapping("/customers/silver")
    public List<Customer> getSilverCustomers(@RequestParam(defaultValue = "1000") double minCreditLine) {
        return mainService.getSilverAndAboveCustomers(minCreditLine);
    }
    //  COMPUTER endpoints
    @PostMapping("/product/computer")
    public Computer addComputer(@RequestBody Computer computer) {
        return mainService.saveComputer(computer);
    }

    @GetMapping("/product/computers")
    public List<Computer> getAllComputers() {
        return mainService.getAllComputers();
    }

    //  LAPTOP endpoints
    @PostMapping("/product/laptop")
    public Laptop addLaptop(@RequestBody Laptop laptop) {
        return mainService.saveLaptop(laptop);
    }

    @GetMapping("/product/laptops")
    public List<Laptop> getAllLaptops() {
        return mainService.getAllLaptops();
    }

    //  PRINTER endpoints
    @PostMapping("/product/printer")
    public Printer addPrinter(@RequestBody Printer printer) {
        return mainService.savePrinter(printer);
    }

    @GetMapping("/product/printers")
    public List<Printer> getAllPrinters() {
        return mainService.getAllPrinters();
    }

    @GetMapping("/report/total-amount-per-card")
    public List<CreditCardTotalDTO> getTotalAmountPerCreditCard() {
        return mainService.getTotalAmountPerCreditCard();
    }

    @GetMapping("/report/top-customers")
    public List<TopCustomerDTO> getTop10Customers() {
        return mainService.getTop10Customers();
    }

    @GetMapping("/report/most-frequent-products")
    public List<ProductFrequencyDTO> getMostFrequentProducts(
            @RequestParam String startDate,
            @RequestParam String endDate
    ) {
        return mainService.getMostFrequentProducts(LocalDate.parse(startDate), LocalDate.parse(endDate));
    }

    @GetMapping("/report/product-customer-reach")
    public List<ProductCustomerReachDTO> getProductsByCustomerReach(
            @RequestParam String startDate,
            @RequestParam String endDate
    ) {
        return mainService.getProductsByCustomerReach(LocalDate.parse(startDate), LocalDate.parse(endDate));
    }

    @GetMapping("/report/max-basket-total")
    public List<MaxBasketPerCardDTO> getMaxBasketTotalPerCard(
            @RequestParam String startDate,
            @RequestParam String endDate
    ) {
        return mainService.getMaxBasketTotalPerCard(LocalDate.parse(startDate), LocalDate.parse(endDate));
    }

    @GetMapping("/report/avg-price-by-type")
    public List<AveragePriceByTypeDTO> getAvgPricePerProductType() {
        return mainService.getAvgPricePerProductType();
    }



}
