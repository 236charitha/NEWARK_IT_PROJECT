package com.charitha.mydmsdapp.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AppearsIn {

    @EmbeddedId
    private AppearsInId id;

    @ManyToOne
    @MapsId("basketId")  // maps basketId from AppearsInId
    @JoinColumn(name = "bid")
    @JsonIgnoreProperties({"appearsInList", "hibernateLazyInitializer", "handler"})
    private Basket basket;

    @ManyToOne
    @MapsId("productId")  // maps productId from AppearsInId
    @JoinColumn(name = "pid")
    @JsonIgnoreProperties({"appearsInList", "hibernateLazyInitializer", "handler"})
    private Product product;

    private Integer quantity;
    private Double price;
}
