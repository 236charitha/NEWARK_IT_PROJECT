package com.charitha.mydmsdapp.entity;

import java.io.Serializable;
import java.util.Objects;

public class ShippingAddressId implements Serializable {

    private String saName;
    private Integer customer;

    public ShippingAddressId() {
    }

    public ShippingAddressId(String saName, Integer customer) {
        this.saName = saName;
        this.customer = customer;
    }

    public String getSaName() {
        return saName;
    }

    public void setSaName(String saName) {
        this.saName = saName;
    }

    public Integer getCustomer() {
        return customer;
    }

    public void setCustomer(Integer customer) {
        this.customer = customer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ShippingAddressId)) return false;
        ShippingAddressId that = (ShippingAddressId) o;
        return Objects.equals(saName, that.saName) &&
                Objects.equals(customer, that.customer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(saName, customer);
    }
}
