// ComputerRepository.java
package com.charitha.mydmsdapp.repository;

import com.charitha.mydmsdapp.entity.Computer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComputerRepository extends JpaRepository<Computer, Integer> {
}
