package com.charitha.mydmsdapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MydmsdappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MydmsdappApplication.class, args);
	}

}
