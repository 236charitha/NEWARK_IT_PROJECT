package com.charitha.mydmsdapp.repository;

import com.charitha.mydmsdapp.entity.AppearsIn;
import com.charitha.mydmsdapp.entity.AppearsInId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AppearsInRepository extends JpaRepository<AppearsIn, AppearsInId> {

    // ✅ To fetch all entries for a basket
    List<AppearsIn> findByIdBasketId(Integer basketId);

    // ✅ To delete a product from basket
    void deleteByIdBasketIdAndIdProductId(Integer basketId, Integer productId);
}
