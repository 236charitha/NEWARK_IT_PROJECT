package com.charitha.mydmsdapp.entity;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("Computer")
public class Computer extends Product {

    private String cPUType;

    public String getcPUType() {
        return cPUType;
    }

    public void setcPUType(String cPUType) {
        this.cPUType = cPUType;
    }
}
