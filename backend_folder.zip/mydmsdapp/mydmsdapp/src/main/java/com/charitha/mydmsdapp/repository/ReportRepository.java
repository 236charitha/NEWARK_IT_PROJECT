package com.charitha.mydmsdapp.repository;

import com.charitha.mydmsdapp.dto.*;
import com.charitha.mydmsdapp.entity.Transaction;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ReportRepository extends CrudRepository<Transaction, Integer> {

    @Query(value = "SELECT cc_number, SUM(total_amount) AS total FROM transaction GROUP BY cc_number", nativeQuery = true)
    List<Object[]> getTotalAmountPerCreditCard();

    @Query(value = """
        SELECT c.cid, c.fname, c.lname, SUM(t.total_amount) AS total
        FROM customer c
        JOIN basket b ON c.cid = b.cid
        JOIN transaction t ON b.bid = t.bid
        GROUP BY c.cid
        ORDER BY total DESC
        LIMIT 10
    """, nativeQuery = true)
    List<Object[]> getTop10Customers();

    @Query(value = """
         SELECT ai.pid, COUNT(*) AS frequency
                        FROM transaction t
                        JOIN basket b ON t.bid = b.bid
                        JOIN appears_in ai ON b.bid = ai.bid
                        WHERE t.date BETWEEN '2025-01-01' AND '2025-05-01'
                        GROUP BY ai.pid
                        ORDER BY frequency DESC
    """, nativeQuery = true)
    List<Object[]> getMostFrequentProducts(LocalDate startDate, LocalDate endDate);

    @Query(value = """
        SELECT ai.pid, COUNT(DISTINCT b.cid) AS customer_count
        FROM transaction t
        JOIN basket b ON t.bid = b.bid
        JOIN appears_in ai ON b.bid = ai.bid
        WHERE t.date BETWEEN :startDate AND :endDate
        GROUP BY ai.pid
        ORDER BY customer_count DESC
    """, nativeQuery = true)
    List<Object[]> getProductsByCustomerReach(LocalDate startDate, LocalDate endDate);

    @Query(value = """
        SELECT cc_number, MAX(total_amount) AS max_total
        FROM transaction
        WHERE date BETWEEN :startDate AND :endDate
        GROUP BY cc_number
    """, nativeQuery = true)
    List<Object[]> getMaxBasketTotalPerCard(LocalDate startDate, LocalDate endDate);

    @Query(value = """
        SELECT product_type, AVG(p_price)
        FROM product
        GROUP BY product_type
    """, nativeQuery = true)
    List<Object[]> getAvgPricePerProductType();
}
