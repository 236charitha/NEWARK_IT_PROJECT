package com.charitha.mydmsdapp.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import java.util.List;

@Entity
public class Basket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer bid;

    @ManyToOne
    @JoinColumn(name = "cid")
    private Customer customer;

    @OneToMany(mappedBy = "basket", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference(value = "basket-appearsin")
    private List<AppearsIn> appearsInList;

    // Getters and Setters
    public Integer getBid() {
        return bid;
    }

    public void setBid(Integer bid) {
        this.bid = bid;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<AppearsIn> getAppearsInList() {
        return appearsInList;
    }

    public void setAppearsInList(List<AppearsIn> appearsInList) {
        this.appearsInList = appearsInList;
    }
}
