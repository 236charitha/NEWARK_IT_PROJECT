package com.charitha.mydmsdapp.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

@Entity
@IdClass(ShippingAddressId.class)
public class ShippingAddress {

    @Id
    private String saName;

    @Id
    @ManyToOne
    @JoinColumn(name = "cid")
    @JsonBackReference(value = "customer-shipping")
    private Customer customer;

    private String recepientName;
    private String street;
    private String sNumber;
    private String city;
    private String zip;
    private String state;
    private String country;

    // ✅ Setter
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    // ✅ Getter (optional, if you use Jackson to serialize this side too)
    public Customer getCustomer() {
        return customer;
    }
}
