package com.charitha.mydmsdapp.dto;

public class AveragePriceByTypeDTO {
    private String type;
    private Double averagePrice;

    public AveragePriceByTypeDTO(String type, Double averagePrice) {
        this.type = type;
        this.averagePrice = averagePrice;
    }

    public String getType() {
        return type;
    }

    public Double getAveragePrice() {
        return averagePrice;
    }
}
