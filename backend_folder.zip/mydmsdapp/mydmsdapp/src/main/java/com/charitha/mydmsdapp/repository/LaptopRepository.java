// LaptopRepository.java
package com.charitha.mydmsdapp.repository;

import com.charitha.mydmsdapp.entity.Laptop;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LaptopRepository extends JpaRepository<Laptop, Integer> {
}
