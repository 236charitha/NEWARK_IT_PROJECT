package com.charitha.mydmsdapp.repository;

import com.charitha.mydmsdapp.entity.Basket;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BasketRepository extends JpaRepository<Basket, Integer> {
    List<Basket> findByCustomerCid(Integer customerId);
}
