package com.charitha.mydmsdapp.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "credit_card")
public class CreditCard {

    @Id
    @Column(name = "cc_number", nullable = false, length = 20)
    private String cc_number;

    @Column(name = "sec_number")
    private String sec_number;

    @Column(name = "owner_name")
    private String owner_name;

    @Column(name = "cc_type")
    private String cc_type;

    @Column(name = "bil_address")
    private String bil_address;

    @Column(name = "exp_date")
    private LocalDate exp_date;

    @ManyToOne
    @JoinColumn(name = "stored_cardcid", nullable = false)  // Match DB exactly
    @JsonBackReference(value = "customer-creditcards")
    private Customer customer;

    // Getters and Setters

    public String getCcNumber() {
        return cc_number;
    }

    public void setCcNumber(String ccNumber) {
        this.cc_number = ccNumber;
    }

    public String getSecNumber() {
        return sec_number;
    }

    public void setSecNumber(String secNumber) {
        this.sec_number = secNumber;
    }

    public String getOwnerName() {
        return owner_name;
    }

    public void setOwnerName(String ownerName) {
        this.owner_name = ownerName;
    }

    public String getCcType() {
        return cc_type;
    }

    public void setCcType(String ccType) {
        this.cc_type = ccType;
    }

    public String getBilAddress() {
        return bil_address;
    }

    public void setBilAddress(String bilAddress) {
        this.bil_address = bilAddress;
    }

    public LocalDate getExpDate() {
        return exp_date;
    }

    public void setExpDate(LocalDate expDate) {
        this.exp_date = expDate;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

}
