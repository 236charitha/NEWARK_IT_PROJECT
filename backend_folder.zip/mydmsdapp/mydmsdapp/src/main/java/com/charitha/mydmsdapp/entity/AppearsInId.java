package com.charitha.mydmsdapp.entity;

import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class AppearsInId implements Serializable {

    private Integer basketId;
    private Integer productId;

    public AppearsInId() {}

    public AppearsInId(Integer basketId, Integer productId) {
        this.basketId = basketId;
        this.productId = productId;
    }

    public Integer getBasketId() {
        return basketId;
    }

    public void setBasketId(Integer basketId) {
        this.basketId = basketId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AppearsInId)) return false;
        AppearsInId that = (AppearsInId) o;
        return Objects.equals(basketId, that.basketId) && Objects.equals(productId, that.productId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(basketId, productId);
    }
}
