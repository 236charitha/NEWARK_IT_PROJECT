package com.charitha.mydmsdapp.dto;

public class ProductCustomerReachDTO {
    private Integer productId;
    private Long customerCount;

    public ProductCustomerReachDTO(Integer productId, Long customerCount) {
        this.productId = productId;
        this.customerCount = customerCount;
    }

    public Integer getProductId() {
        return productId;
    }

    public Long getCustomerCount() {
        return customerCount;
    }
}
