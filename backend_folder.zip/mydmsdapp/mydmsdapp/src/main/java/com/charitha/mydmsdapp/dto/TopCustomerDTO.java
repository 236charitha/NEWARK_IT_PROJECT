package com.charitha.mydmsdapp.dto;

public class TopCustomerDTO {
    private Integer cid;
    private String name;
    private Double totalSpent;

    public TopCustomerDTO(Integer cid, String name, Double totalSpent) {
        this.cid = cid;
        this.name = name;
        this.totalSpent = totalSpent;
    }

    public Integer getCid() {
        return cid;
    }

    public String getName() {
        return name;
    }

    public Double getTotalSpent() {
        return totalSpent;
    }
}
