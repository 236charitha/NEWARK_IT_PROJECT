package com.charitha.mydmsdapp.dto;

public class MaxBasketPerCardDTO {
    private String ccNumber;
    private Double maxAmount;

    public MaxBasketPerCardDTO(String ccNumber, Double maxAmount) {
        this.ccNumber = ccNumber;
        this.maxAmount = maxAmount;
    }

    public String getCcNumber() {
        return ccNumber;
    }

    public Double getMaxAmount() {
        return maxAmount;
    }
}
