package com.charitha.mydmsdapp.repository;

import com.charitha.mydmsdapp.entity.OfferProduct;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OfferProductRepository extends JpaRepository<OfferProduct, Integer> {
}
