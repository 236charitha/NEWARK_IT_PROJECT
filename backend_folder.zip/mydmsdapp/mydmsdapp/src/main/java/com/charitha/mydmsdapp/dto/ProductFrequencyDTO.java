package com.charitha.mydmsdapp.dto;

public class ProductFrequencyDTO {
    private Integer productId;
    private Long frequency;

    public ProductFrequencyDTO(Integer productId, Long frequency) {
        this.productId = productId;
        this.frequency = frequency;
    }

    public Integer getProductId() {
        return productId;
    }

    public Long getFrequency() {
        return frequency;
    }
}
