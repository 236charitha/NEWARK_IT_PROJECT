package com.charitha.mydmsdapp.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "transaction") // Use this to ensure correct mapping to the table named 'transaction'
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer tid;



    private LocalDate date;

    @ManyToOne
    @JoinColumn(name = "bid", nullable = false)
    private Basket basket;

    @ManyToOne
    @JoinColumn(name = "cc_number", referencedColumnName = "cc_number", nullable = false)
    private CreditCard creditCard;

    private Double totalAmount;

    // Getters and Setters
    public Integer getTid() {
        return tid;
    }

    public void setTid(Integer tid) {
        this.tid = tid;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Basket getBasket() {
        return basket;
    }

    public void setBasket(Basket basket) {
        this.basket = basket;
    }

    public CreditCard getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(CreditCard creditCard) {
        this.creditCard = creditCard;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }


}
