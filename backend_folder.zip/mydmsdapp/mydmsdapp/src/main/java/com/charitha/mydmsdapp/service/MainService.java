package com.charitha.mydmsdapp.service;

import com.charitha.mydmsdapp.dto.*;
import com.charitha.mydmsdapp.entity.*;
import com.charitha.mydmsdapp.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class MainService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CreditCardRepository creditCardRepository;

    @Autowired
    private ShippingAddressRepository shippingAddressRepository;

    @Autowired
    private BasketRepository basketRepository;

    @Autowired
    private AppearsInRepository appearsInRepository;

    @Autowired
    private OfferProductRepository offerProductRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private ComputerRepository computerRepository;

    @Autowired
    private LaptopRepository laptopRepository;

    @Autowired
    private PrinterRepository printerRepository;

    @Autowired
    private ReportRepository reportRepository;






    public List<CreditCardTotalDTO> getTotalAmountPerCreditCard() {
        return reportRepository.getTotalAmountPerCreditCard().stream()
                .map(obj -> new CreditCardTotalDTO((String) obj[0], (Double) obj[1]))
                .toList();
    }

    public List<TopCustomerDTO> getTop10Customers() {
        return reportRepository.getTop10Customers().stream()
                .map(obj -> new TopCustomerDTO((Integer) obj[0], obj[1] + " " + obj[2], (Double) obj[3]))
                .toList();
    }

    public List<ProductFrequencyDTO> getMostFrequentProducts(LocalDate startDate, LocalDate endDate) {
        return reportRepository.getMostFrequentProducts(startDate, endDate).stream()
                .map(obj -> new ProductFrequencyDTO((Integer) obj[0], ((Number) obj[1]).longValue()))
                .toList();
    }

    public List<ProductCustomerReachDTO> getProductsByCustomerReach(LocalDate startDate, LocalDate endDate) {
        return reportRepository.getProductsByCustomerReach(startDate, endDate).stream()
                .map(obj -> new ProductCustomerReachDTO((Integer) obj[0], ((Number) obj[1]).longValue()))
                .toList();
    }

    public List<MaxBasketPerCardDTO> getMaxBasketTotalPerCard(LocalDate startDate, LocalDate endDate) {
        return reportRepository.getMaxBasketTotalPerCard(startDate, endDate).stream()
                .map(obj -> new MaxBasketPerCardDTO((String) obj[0], (Double) obj[1]))
                .toList();
    }

    public List<AveragePriceByTypeDTO> getAvgPricePerProductType() {
        return reportRepository.getAvgPricePerProductType().stream()
                .map(obj -> new AveragePriceByTypeDTO((String) obj[0], (Double) obj[1]))
                .toList();
    }




    // ✅ Register new customer
    public Customer registerCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    // ✅ Get customer by ID
    public Optional<Customer> getCustomerById(int id) {
        return customerRepository.findById(id);
    }

    // ✅ Update customer
    public Customer updateCustomer(int id, Customer updatedCustomer) {
        Customer existing = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        existing.setFname(updatedCustomer.getFname());
        existing.setLname(updatedCustomer.getLname());
        existing.setEmail(updatedCustomer.getEmail());
        existing.setPhone(updatedCustomer.getPhone());
        existing.setAddress(updatedCustomer.getAddress());
        existing.setStatus(updatedCustomer.getStatus());
        existing.setCreditLine(updatedCustomer.getCreditLine());
        return customerRepository.save(existing);
    }

    // ✅ Delete customer
    public void deleteCustomer(int id) {
        customerRepository.deleteById(id);
    }

    // ✅ Add or update credit card
    public CreditCard saveCreditCard(CreditCard creditCard, Integer customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        creditCard.setCustomer(customer);
        return creditCardRepository.save(creditCard);
    }

    // ✅ Get all credit cards for a customer
    public List<CreditCard> getCreditCardsByCustomer(Integer customerId) {
        return creditCardRepository.findByCustomerCid(customerId);
    }

    // ✅ Delete a credit card
    public void deleteCreditCard(String ccNumber) {
        creditCardRepository.deleteById(ccNumber);
    }

    // ✅ Add or update shipping address
    public ShippingAddress saveShippingAddress(ShippingAddress address, Integer customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        address.setCustomer(customer);
        return shippingAddressRepository.save(address);
    }

    // ✅ Get all shipping addresses for a customer
    public List<ShippingAddress> getShippingAddressesByCustomer(Integer customerId) {
        return shippingAddressRepository.findByCustomerCid(customerId);
    }

    // ✅ Delete a shipping address by name
    public void deleteShippingAddress(Integer customerId, String saName) {
        shippingAddressRepository.deleteByCustomerCidAndSaName(customerId, saName);
    }

    // ✅ Create a new basket for a customer
    public Basket createBasketForCustomer(Integer customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        Basket basket = new Basket();
        basket.setCustomer(customer);
        return basketRepository.save(basket);
    }

    // ✅ Get all baskets for a customer
    public List<Basket> getBasketsByCustomer(Integer customerId) {
        return basketRepository.findByCustomerCid(customerId);
    }

    // ✅ Delete a basket by ID
    public void deleteBasket(Integer basketId) {
        basketRepository.deleteById(basketId);
    }
    public AppearsIn addProductToBasket(Integer basketId, AppearsIn appearsIn) {
        Basket basket = basketRepository.findById(basketId)
                .orElseThrow(() -> new RuntimeException("Basket not found"));
        appearsIn.setBasket(basket);
        return appearsInRepository.save(appearsIn);
    }

    public List<AppearsIn> getProductsInBasket(Integer basketId) {
        return appearsInRepository.findByIdBasketId(basketId);
    }

    public void removeProductFromBasket(Integer basketId, Integer productId) {
        appearsInRepository.deleteByIdBasketIdAndIdProductId(basketId, productId);
    }





    // ✅ Create or update offer product
    public OfferProduct saveOfferProduct(OfferProduct offerProduct) {
        return offerProductRepository.save(offerProduct);
    }

    // ✅ Get all offer products
    public List<OfferProduct> getAllOfferProducts() {
        return offerProductRepository.findAll();
    }

    // ✅ Delete an offer product
    public void deleteOfferProduct(Integer offerId) {
        offerProductRepository.deleteById(offerId);
    }

    // ✅ Place a transaction (order)
    public Transaction placeTransaction(Transaction transaction, Integer basketId, String ccNumber) {
        Basket basket = basketRepository.findById(basketId)
                .orElseThrow(() -> new RuntimeException("Basket not found"));

        CreditCard creditCard = creditCardRepository.findById(ccNumber)
                .orElseThrow(() -> new RuntimeException("Credit card not found"));

        transaction.setBasket(basket);
        transaction.setCreditCard(creditCard);
        return transactionRepository.save(transaction);
    }

    // ✅ Get all transactions for a basket
    public List<Transaction> getTransactionsByBasket(Integer basketId) {
        return transactionRepository.findByBasketBid(basketId);
    }
    public Transaction saveTransaction(Transaction transaction) {
        return transactionRepository.save(transaction);
    }
    public List<Customer> getSilverAndAboveCustomers(double minCreditLine) {
        return customerRepository.findByCreditLineGreaterThan(minCreditLine);
    }


    // ✅ Save or update computer
    public Computer saveComputer(Computer computer) {
        return computerRepository.save(computer);
    }

    // ✅ Save or update laptop
    public Laptop saveLaptop(Laptop laptop) {
        return laptopRepository.save(laptop);
    }

    // ✅ Save or update printer
    public Printer savePrinter(Printer printer) {
        return printerRepository.save(printer);
    }

    // ✅ Get all computers/laptops/printers
    public List<Computer> getAllComputers() {
        return computerRepository.findAll();
    }

    public List<Laptop> getAllLaptops() {
        return laptopRepository.findAll();
    }

    public List<Printer> getAllPrinters() {
        return printerRepository.findAll();
    }








}
