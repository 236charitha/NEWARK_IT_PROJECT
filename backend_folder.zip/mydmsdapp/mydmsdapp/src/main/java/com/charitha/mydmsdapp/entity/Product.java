package com.charitha.mydmsdapp.entity;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;

import java.util.List;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "product_type", discriminatorType = DiscriminatorType.STRING)
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "product_type"
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = Computer.class, name = "Computer"),
        @JsonSubTypes.Type(value = Laptop.class, name = "Laptop"),
        @JsonSubTypes.Type(value = Printer.class, name = "Printer")
})
public abstract class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pid;

    private String pName;
    private Double pPrice;

    @Column(length = 1000)
    private String description;

    private Integer pQuantity;

    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference(value = "product-appearsin")
    private List<AppearsIn> appearsInList;

    // Getters and Setters
    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public Double getpPrice() {
        return pPrice;
    }

    public void setpPrice(Double pPrice) {
        this.pPrice = pPrice;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getpQuantity() {
        return pQuantity;
    }

    public void setpQuantity(Integer pQuantity) {
        this.pQuantity = pQuantity;
    }

    public List<AppearsIn> getAppearsInList() {
        return appearsInList;
    }

    public void setAppearsInList(List<AppearsIn> appearsInList) {
        this.appearsInList = appearsInList;
    }
}
