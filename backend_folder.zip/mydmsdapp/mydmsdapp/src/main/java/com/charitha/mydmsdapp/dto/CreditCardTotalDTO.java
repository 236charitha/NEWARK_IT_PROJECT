package com.charitha.mydmsdapp.dto;

public class CreditCardTotalDTO {
    private String ccNumber;
    private Double totalAmount;

    public CreditCardTotalDTO(String ccNumber, Double totalAmount) {
        this.ccNumber = ccNumber;
        this.totalAmount = totalAmount;
    }

    public String getCcNumber() {
        return ccNumber;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }
}
