package com.charitha.mydmsdapp.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "CUSTOMER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cid;

    @Column(name = "FName")
    private String fname;

    @Column(name = "LName")
    private String lname;

    @Column(name = "EMail")
    private String email;

    @Column(name = "Phone")
    private String phone;

    @Column(name = "Address")
    private String address;

    @Column(name = "Status")
    private String status;  // e.g. REGULAR, SILVER, GOLD, PLATINUM

    @Column(name = "CreditLine")
    private Double creditLine;
}
