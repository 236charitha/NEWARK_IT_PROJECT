// ✅ GLOBAL CONFIG
const apiBase = 'http://localhost:8080/api';

// ✅ CUSTOMER MANAGEMENT
window.onload = function () {
  const storedId = localStorage.getItem('registeredCustomerId');
  if (storedId) {
    document.getElementById('saCustomerId')?.value = storedId;
    document.getElementById('viewCustomerId')?.value = storedId;
    document.getElementById('basketCustomerId')?.value = storedId;
    document.getElementById('viewBasketsCustomerId')?.value = storedId;
  }
};

// ✅ POST: Register Customer
document.getElementById('customerForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  const customerData = {
    fname: document.getElementById('fname').value,
    lname: document.getElementById('lname').value,
    email: document.getElementById('email').value,
    address: document.getElementById('address').value,
    phone: document.getElementById('phone').value,
    status: document.getElementById('status').value
  };

  fetch(`${apiBase}/customer`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(customerData)
  })
  .then(res => res.json())
  .then(data => {
    alert(`✅ Customer registered with ID: ${data.cid}`);
    localStorage.setItem('registeredCustomerId', data.cid);
  })
  .catch(err => {
    console.error(err);
    alert('❌ Failed to register customer.');
  });
});

function getCustomer() {
  const id = document.getElementById('customerId').value;
  fetch(`${apiBase}/customer/${id}`)
    .then(res => res.json())
    .then(data => {
      document.getElementById('customerDetails').innerText = `Customer: ${data.fname} ${data.lname}, Email: ${data.email}`;
    })
    .catch(err => {
      console.error(err);
      document.getElementById('customerDetails').innerText = '❌ Customer not found';
    });
}

function deleteCustomer() {
  const id = document.getElementById('customerId').value;
  fetch(`${apiBase}/customer/${id}`, { method: 'DELETE' })
    .then(res => res.text())
    .then(msg => {
      document.getElementById('customerDetails').innerText = `🗑️ ${msg}`;
    })
    .catch(err => {
      console.error(err);
      document.getElementById('customerDetails').innerText = '❌ Failed to delete customer';
    });
}

// ✅ PUT: Update Customer
document.getElementById('updateForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  const id = document.getElementById('customerId').value;
  const updatedData = {
    fname: document.getElementById('ufname').value,
    lname: document.getElementById('ulname').value,
    email: document.getElementById('uemail').value,
    address: document.getElementById('uaddress').value,
    phone: document.getElementById('uphone').value,
    status: document.getElementById('ustatus').value
  };

  fetch(`${apiBase}/customer/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updatedData)
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById('customerDetails').innerText = `✅ Customer updated: ${data.fname} ${data.lname}`;
  })
  .catch(err => {
    console.error(err);
    document.getElementById('customerDetails').innerText = '❌ Failed to update customer';
  });
});

window.getCustomer = getCustomer;
window.deleteCustomer = deleteCustomer;

// ✅ CREDIT CARD MANAGEMENT
document.getElementById('creditCardForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  const customerId = document.getElementById('ccCustomerId').value;
  const creditCardData = {
    ccNumber: document.getElementById('ccNumber').value,
    secNumber: document.getElementById('secNumber').value,
    ownerName: document.getElementById('ownerName').value,
    ccType: document.getElementById('ccType').value,
    bilAddress: document.getElementById('bilAddress').value,
    expDate: document.getElementById('expDate').value
  };

  fetch(`${apiBase}/customer/${customerId}/creditcard`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(creditCardData)
  })
  .then(res => res.json())
  .then(() => alert(`✅ Credit card saved for customer ID: ${customerId}`))
  .catch(() => alert('❌ Failed to save credit card.'));
});

function getCreditCards() {
  const customerId = document.getElementById('viewCCCustomerId').value;
  fetch(`${apiBase}/customer/${customerId}/creditcards`)
    .then(res => res.json())
    .then(cards => {
      const list = document.getElementById('cardList');
      list.innerHTML = '';
      cards.forEach(card => {
        const li = document.createElement('li');
        li.textContent = `${card.ccType} - ${card.ccNumber} (Exp: ${card.expDate})`;
        list.appendChild(li);
      });
    })
    .catch(() => alert('❌ Failed to fetch credit cards.'));
}

function deleteCreditCard() {
  const ccNumber = document.getElementById('deleteCCNumber').value;
  fetch(`${apiBase}/creditcard/${ccNumber}`, { method: 'DELETE' })
    .then(res => res.text())
    .then(msg => alert(`🗑️ ${msg}`))
    .catch(() => alert('❌ Failed to delete credit card.'));
}

// ✅ SHIPPING ADDRESS MANAGEMENT
document.getElementById('shippingForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  const customerId = document.getElementById('saCustomerId').value;
  const addressData = {
    saName: document.getElementById('saName').value,
    recepientName: document.getElementById('recepientName').value,
    street: document.getElementById('street').value,
    sNumber: document.getElementById('sNumber').value,
    city: document.getElementById('city').value,
    zip: document.getElementById('zip').value,
    state: document.getElementById('state').value,
    country: document.getElementById('country').value
  };

  fetch(`${apiBase}/customer/${customerId}/shippingaddress`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(addressData)
  })
  .then(res => res.json())
  .then(() => alert('✅ Address added successfully!'))
  .catch(() => alert('❌ Failed to add address.'));
});

function getShippingAddresses() {
  const customerId = document.getElementById('viewCustomerId').value;
  fetch(`${apiBase}/customer/${customerId}/shippingaddresses`)
    .then(res => res.json())
    .then(addresses => {
      const list = document.getElementById('addressList');
      list.innerHTML = '';
      addresses.forEach(addr => {
        const li = document.createElement('li');
        li.textContent = `${addr.saName} - ${addr.street}, ${addr.city}, ${addr.state}`;
        list.appendChild(li);
      });
    })
    .catch(() => alert('❌ Failed to fetch addresses.'));
}

function deleteShippingAddress() {
  const customerId = document.getElementById('viewCustomerId').value;
  const saName = document.getElementById('deleteSaName').value;

  fetch(`${apiBase}/customer/${customerId}/shippingaddress/${saName}`, { method: 'DELETE' })
    .then(res => res.text())
    .then(msg => {
      alert(`🗑️ ${msg}`);
      getShippingAddresses();
    })
    .catch(() => alert('❌ Failed to delete address.'));
}

// ✅ BASKET + TRANSACTION MANAGEMENT (from basket.html)
// ... (already implemented correctly in your other file)

// ✅ PRODUCT CREATION
document.getElementById('computerForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  const comp = {
    pName: document.getElementById('compName').value,
    pPrice: document.getElementById('compPrice').value,
    description: document.getElementById('compDesc').value,
    pQuantity: document.getElementById('compQty').value,
    cPUType: document.getElementById('compCPU').value
  };
  fetch(`${apiBase}/product/computer`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(comp)
  })
  .then(res => res.json())
  .then(() => alert('✅ Computer added.'))
  .catch(() => alert('❌ Failed to add computer.'));
});

document.getElementById('laptopForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  const lap = {
    pName: document.getElementById('lapName').value,
    pPrice: document.getElementById('lapPrice').value,
    description: document.getElementById('lapDesc').value,
    pQuantity: document.getElementById('lapQty').value,
    bType: document.getElementById('lapType').value,
    weight: document.getElementById('lapWeight').value
  };
  fetch(`${apiBase}/product/laptop`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(lap)
  })
  .then(res => res.json())
  .then(() => alert('✅ Laptop added.'))
  .catch(() => alert('❌ Failed to add laptop.'));
});

document.getElementById('printerForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  const print = {
    pName: document.getElementById('printName').value,
    pPrice: document.getElementById('printPrice').value,
    description: document.getElementById('printDesc').value,
    pQuantity: document.getElementById('printQty').value,
    printerType: document.getElementById('printType').value,
    resolution: document.getElementById('printRes').value
  };
  fetch(`${apiBase}/product/printer`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(print)
  })
  .then(res => res.json())
  .then(() => alert('✅ Printer added.'))
  .catch(() => alert('❌ Failed to add printer.'));
});

// ✅ View All Products
function getAllProducts() {
  Promise.all([
    fetch(`${apiBase}/product/computers`).then(r => r.json()),
    fetch(`${apiBase}/product/laptops`).then(r => r.json()),
    fetch(`${apiBase}/product/printers`).then(r => r.json())
  ]).then(([comps, laps, prints]) => {
    const list = document.getElementById('productList');
    list.innerHTML = '';
    comps.forEach(p => list.innerHTML += `<li>🖥️ Computer: ${p.pName} (${p.pid})</li>`);
    laps.forEach(p => list.innerHTML += `<li>💻 Laptop: ${p.pName} (${p.pid})</li>`);
    prints.forEach(p => list.innerHTML += `<li>🖨️ Printer: ${p.pName} (${p.pid})</li>`);
  }).catch(() => alert('❌ Failed to fetch products.'));
}

window.getCreditCards = getCreditCards;
window.deleteCreditCard = deleteCreditCard;
window.getShippingAddresses = getShippingAddresses;
window.deleteShippingAddress = deleteShippingAddress;
window.createBasket = createBasket;
window.getBaskets = getBaskets;
window.addProductToBasket = addProductToBasket;
window.getProductsInBasket = getProductsInBasket;
window.removeProductFromBasket = removeProductFromBasket;
window.placeOrder = placeOrder;
window.getAllProducts = getAllProducts;
function placeOrder() {
    const basketId = document.getElementById('checkoutBasketId').value;
  
    const order = {
      date: new Date().toISOString().split("T")[0],  // e.g., "2025-12-01"
      totalAmount: parseFloat(document.getElementById('checkoutAmount').value),
      creditCard: {
        ccNumber: document.getElementById('checkoutTransactionType').value  // here it's actually ccNumber input
      }
    };
    function getProductsInBasket() {
        const basketId = document.getElementById("viewBasketId").value;
      
        fetch(`${apiBase}/basket/${basketId}/products`)
          .then(res => {
            if (!res.ok) throw new Error("Failed to fetch products");
            return res.json();
          })
          .then(products => {
            const list = document.getElementById("basketProductList");
            list.innerHTML = "";
      
            if (!products || products.length === 0) {
              list.innerHTML = "<li>No products found in basket.</li>";
              return;
            }
      
            products.forEach(p => {
              const li = document.createElement("li");
              li.textContent = `Product: ${p.product.pName} | Qty: ${p.quantity}`;
              list.appendChild(li);
            });
          })
          .catch(err => {
            console.error(err);
            alert("❌ Error fetching products in basket.");
          });
      }
      
  
    fetch(`$${apiBase}/basket/${basketId}/transaction`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(order)
    })
    .then(res => {
      if (!res.ok) throw new Error("Failed to place order");
      return res.json();
    })
    .then(data => {
      const transactionId = data.tid || data.id || data.transactionId;
      if (transactionId) {
        alert(`✅ Order placed! Transaction ID: ${transactionId}`);
      } else {
        alert(`✅ Order placed, but no ID returned. Raw response: ${JSON.stringify(data)}`);
      }
    })
    .catch(err => {
      console.error(err);
      alert("❌ Could not place the order.");
    });
  }
  
  function getTransactionsByBasket() {
    const basketId = document.getElementById("historyBasketId").value;
  
    fetch(`$${apiBase}/basket/${basketId}/transactions`)
      .then(res => {
        if (!res.ok) throw new Error("Failed to fetch transactions");
        return res.json();
      })
      .then(transactions => {
        const list = document.getElementById("transactionList");
        list.innerHTML = "";
  
        if (!transactions || transactions.length === 0) {
          list.innerHTML = "<li>No transactions found for this basket.</li>";
          return;
        }
  
        transactions.forEach(t => {
          const li = document.createElement("li");
          li.textContent = `🧾 ID: ${t.tid}, Date: ${t.date}, Amount: $${t.totalAmount}, Card: ${t.creditCard?.ccNumber ?? 'N/A'}`;
          list.appendChild(li);
        });
      })
      .catch(err => {
        console.error("❌ Fetch failed:", err);
        alert("❌ Failed to fetch transaction history.");
      });
  }
  