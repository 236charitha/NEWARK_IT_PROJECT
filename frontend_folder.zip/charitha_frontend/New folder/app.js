window.onload = function () {

    // ✅ Enable Next button if a customer was already registered
    const storedCid = localStorage.getItem('registeredCustomerId');
    if (storedCid) {
      const nextBtn = document.getElementById('goToCreditCard');
      if (nextBtn) {
        nextBtn.disabled = false;
      }
    }
  
    // ✅ POST: Register Customer
    document.getElementById('customerForm').addEventListener('submit', function(e) {
      e.preventDefault();
  
      const customerData = {
        fname: document.getElementById('fname').value,
        lname: document.getElementById('lname').value,
        email: document.getElementById('email').value,
        address: document.getElementById('address').value,
        phone: document.getElementById('phone').value,
        status: document.getElementById('status').value
      };
  
      fetch('http://localhost:8080/api/customer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(customerData)
      })
      .then(response => response.json())
      .then(data => {
        alert(`✅ Customer registered with ID: ${data.cid}`);
        localStorage.setItem('registeredCustomerId', data.cid);
  
        // Enable Next button
        const nextBtn = document.getElementById('goToCreditCard');
        if (nextBtn) {
          nextBtn.disabled = false;
          nextBtn.textContent = "Next: Add Credit Card";
        }
      })
      .catch(error => {
        console.error('Error:', error);
        alert('❌ Failed to register customer.');
      });
    });
  
    // ✅ GET: Get Customer by ID
    function getCustomer() {
      const id = document.getElementById('customerId').value;
      fetch(`http://localhost:8080/api/customer/${id}`)
        .then(response => {
          if (!response.ok) throw new Error("Not found");
          return response.json();
        })
        .then(data => {
          document.getElementById('customerDetails').innerText =
            `Customer: ${data.fname} ${data.lname}, Email: ${data.email}`;
          // Pre-fill update form
          document.getElementById('ufname').value = data.fname;
          document.getElementById('ulname').value = data.lname;
          document.getElementById('uemail').value = data.email;
          document.getElementById('uaddress').value = data.address;
          document.getElementById('uphone').value = data.phone;
          document.getElementById('ustatus').value = data.status;
        })
        .catch(error => {
          console.error('Error:', error);
          document.getElementById('customerDetails').innerText = '❌ Customer not found';
        });
    }
  
    // ✅ DELETE: Delete Customer by ID
    function deleteCustomer() {
      const id = document.getElementById('customerId').value;
      fetch(`http://localhost:8080/api/customer/${id}`, {
        method: 'DELETE'
      })
      .then(response => response.text())
      .then(msg => {
        document.getElementById('customerDetails').innerText = `🗑️ ${msg}`;
      })
      .catch(error => {
        console.error('Error:', error);
        document.getElementById('customerDetails').innerText = '❌ Failed to delete customer';
      });
    }
  
    // ✅ PUT: Update Customer
    document.getElementById('updateForm').addEventListener('submit', function(e) {
      e.preventDefault();
      const id = document.getElementById('customerId').value;
  
      const updatedData = {
        fname: document.getElementById('ufname').value,
        lname: document.getElementById('ulname').value,
        email: document.getElementById('uemail').value,
        address: document.getElementById('uaddress').value,
        phone: document.getElementById('uphone').value,
        status: document.getElementById('ustatus').value
      };
  
      fetch(`http://localhost:8080/api/customer/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedData)
      })
      .then(response => response.json())
      .then(data => {
        document.getElementById('customerDetails').innerText =
          `✅ Customer updated: ${data.fname} ${data.lname}`;
      })
      .catch(error => {
        console.error('Error:', error);
        document.getElementById('customerDetails').innerText = '❌ Failed to update customer';
      });
    });
  
    // ✅ NEXT: Go to Credit Card Page
    const nextBtn = document.getElementById('goToCreditCard');
    if (nextBtn) {
      nextBtn.addEventListener('click', function () {
        window.location.href = 'creditcard.html';
      });
    }
  
    // ✅ CREDIT CARD SECTION (Optional here — only applies in creditcard.html)
    const creditForm = document.getElementById('creditCardForm');
    if (creditForm) {
      // Prefill stored ID
      const storedId = localStorage.getItem('registeredCustomerId');
      if (storedId) {
        document.getElementById('ccCustomerId').value = storedId;
        document.getElementById('viewCCCustomerId').value = storedId;
      }
  
      // Add Credit Card
      creditForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const customerId = document.getElementById('ccCustomerId').value;
  
        const creditCardData = {
          ccNumber: document.getElementById('ccNumber').value,
          secNumber: document.getElementById('secNumber').value,
          ownerName: document.getElementById('ownerName').value,
          ccType: document.getElementById('ccType').value,
          bilAddress: document.getElementById('bilAddress').value,
          expDate: document.getElementById('expDate').value
        };
  
        fetch(`http://localhost:8080/api/customer/${customerId}/creditcard`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(creditCardData)
        })
        .then(response => response.json())
        .then(data => {
          alert(`✅ Credit card saved for customer ID: ${customerId}`);
          document.getElementById('creditCardForm').reset();
        })
        .catch(error => {
          console.error('Error:', error);
          alert('❌ Failed to save credit card.');
        });
      });
    }
  
    // ✅ View Credit Cards
    window.getCreditCards = function() {
      const customerId = document.getElementById('viewCCCustomerId').value;
  
      fetch(`http://localhost:8080/api/customer/${customerId}/creditcards`)
        .then(response => response.json())
        .then(cards => {
          const list = document.getElementById('cardList');
          list.innerHTML = '';
          if (cards.length === 0) {
            list.innerHTML = '<li>No credit cards found.</li>';
          } else {
            cards.forEach(card => {
              const li = document.createElement('li');
              li.textContent = `${card.ccType} - ${card.ccNumber} (Exp: ${card.expDate})`;
              list.appendChild(li);
            });
          }
        })
        .catch(error => {
          console.error('Error:', error);
          alert('❌ Failed to fetch credit cards.');
        });
    };
  
    // ✅ Delete Credit Card
    window.deleteCreditCard = function() {
      const ccNumber = document.getElementById('deleteCCNumber').value;
  
      fetch(`http://localhost:8080/api/creditcard/${ccNumber}`, {
        method: 'DELETE'
      })
      .then(response => response.text())
      .then(msg => {
        alert(`🗑️ ${msg}`);
        getCreditCards();
      })
      .catch(error => {
        console.error('Error:', error);
        alert('❌ Failed to delete credit card.');
      });
    };
  
    // Expose customer actions
    window.getCustomer = getCustomer;
    window.deleteCustomer = deleteCustomer;
  };
  